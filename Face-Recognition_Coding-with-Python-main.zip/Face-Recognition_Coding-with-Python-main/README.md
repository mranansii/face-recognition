<a> 
   <div align="center"> <h1>Face Recognition (Coding with Python)</h1> 
   <img border="0" src="/icon.gif" width="320" height="240" >
   </div>
</a>

### Run Script in Visual Studio Code

- #### A few python modules and packages are required to download in order to complete this project and have it run properly. 
  - [Install Visual Studio Community](https://visualstudio.microsoft.com/vs/community) and then download Desktop Development with C++ workload in Visual Studio
  - [requirements.txt](https://github.com/serhanelmacioglu/Face-Recognition_Coding-with-Python/blob/main/requirements.txt)
``` python

# Install from a list of packages 
pip install -r requirements.txt

```
